# Web-FoodAPP
Desenvolvimento de aplicação web voltada para redes de fast food e restaurantes!

<html>

<b>Para utilizar o Banco de Dados siga os seguintes passos:

1. Baixe a pasta do BD no link a seguir: <a href="https://www.mediafire.com/folder/wj7e5yeiv0v4b/atlas">Banco de dados - Atlas</a>:

2. Em seguida, extraia a pasta para o seguinte caminho do MYSQL no seu XAMPP;

3. Caminho: xampp/mysql/data

</html>
#   p r o j e t o _ z e f o o d  
 